interface RosterData {
    name: string;
    subscription: string;
    jid: string;
}
export type { RosterData };
